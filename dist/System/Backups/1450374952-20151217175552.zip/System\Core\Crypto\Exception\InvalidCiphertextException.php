<?php
namespace Defuse\Crypto\Exception;

class InvalidCiphertextException extends \Defuse\Crypto\Exception\CryptoException
{
    
}
