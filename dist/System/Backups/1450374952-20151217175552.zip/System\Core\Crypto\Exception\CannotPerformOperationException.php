<?php
namespace Defuse\Crypto\Exception;

class CannotPerformOperation extends \Defuse\Crypto\Exception\CryptoException
{
    
}
