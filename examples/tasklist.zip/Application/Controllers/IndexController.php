<?php
    namespace Application;
    class IndexController extends \xTend\Blueprints\BaseDataController {
        public function index() {
            if($this->tasks===false) {
                $tasks = Task::orderByAsc('created_at')->findMany();
                $this->tasks = $tasks;
            }
            return $this->tasks;
        }
    }
