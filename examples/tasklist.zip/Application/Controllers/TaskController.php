<?php
    namespace Application;
    use \xTend\Core\Session;
    class TaskController extends \xTend\Blueprints\BaseDataController {
        public function post() {
            //get the url handler
            $urlHandler=$this->_app->getUrlHandler();
            //get post data also possible through $_POST
            $post=$this->_app->getRequestDataHandler()->post();
    		//error checks
            if(!$this->_app->getFormTokenHandler()->check('task', $post['token-task'])) {
                return $urlHandler->navigate('', [
    				'Invalid session'
    			]);
            }
    		if(trim($post['name'])=='') {
    			return $urlHandler->navigate('', [
    				'Name is required'
    			]);
    		}
    		if(strlen($post['name'])>255) {
    			return $urlHandler->navigate('', [
    				'Name has to be shorter than 255 characters'
    			]);
    		}
            //create task
    		$t = Task::create();
    		$t->name = $post['name'];
    		$t->save();
            //navigate back
    		return $urlHandler->navigate('');
        }

        public function delete() {
            //get the url handler
            $urlHandler=$this->_app->getUrlHandler();
            //get post
            $post=$this->_app->getRequestDataHandler()->post();
            //checks
            $id = $urlHandler->task;
            if(!$this->_app->getFormTokenHandler()->check('delete', $post['token-delete'])) {
                return $urlHandler->navigate('', [
    				'Invalid session'
    			]);
            }
            Task::findOne($id)->delete();
            return $urlHandler->navigate('');
        }
    }
