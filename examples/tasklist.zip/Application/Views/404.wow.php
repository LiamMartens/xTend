<layout value="app" />
<compile value="change" />
<version value="1" />

<section name="content">
    <h1>404 - Page Not Found</h1>
    <a href="/">Go back</a>
</section>
