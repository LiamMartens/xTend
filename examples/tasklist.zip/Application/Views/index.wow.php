<layout value="app" />
<compile value="change" />
<version value="1" />

<section name="content">
    <div class="panel panel-default">
        <div class="panel-body">
            <module name="errors" />
            <form action="/task" method="POST" class="form-horizontal">
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="name">Task</label>
                    <div class="col-sm-6">
                        <input type="text" name="name" id="name" class="form-control" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-6">
                        <button class="btn btn-default" type="submit">ADD TASK</button>
                    </div>
                </div>
                <formtoken name="task" />
            </form>
        </div>
    </div>
    <if>
        <condition>count(@icontroller:index())</condition>
        <div class="panel panel-default">
            <div class="panel-heading">
                Current tasks
            </div>
            <div class="panel-body">
                <table class="table table-striped">
                    <thead>
                        <th>Task</th>
                        <th>&nbsp;</th>
                    </thead>
                    <tbody>
                        <foreach>
                            <loop>@icontroller:index() as $task</loop>
                            <tr>
                                <td><echo>$task->name</echo></td>
                                <td>
                                    <form action="/task/{{ $task->id }}" method="POST">
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                        <formtoken persistent name="delete" />
                                        <spoof method="delete" />
                                    </form>
                                </td>
                            </tr>
                        </foreach>
                    </tbody>
                </table>
            </div>
        </div>
    </if>
</section>
