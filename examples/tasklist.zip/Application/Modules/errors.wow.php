<if>
    <condition>count(@iapp:getRequestDataHandler()->data()) > 0</condition>
    <div class="alert alert-danger">
        <ul>
            <foreach>
                <loop>@iapp:getRequestDataHandler()->data() as $error</loop>
                <li><echo>$error</echo></li>
            </foreach>
        </ul>
    </div>
</if>
