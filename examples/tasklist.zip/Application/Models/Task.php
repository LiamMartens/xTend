<?php
    namespace Application;
    class Task extends \Model {
        public static $_table = 'tasks';
        public static function create() {
            return \ORM::for_table('tasks')->create();
        }
    }
