<?php
namespace Defuse\Crypto\Exception;

class CryptoException extends \Exception
{

}
