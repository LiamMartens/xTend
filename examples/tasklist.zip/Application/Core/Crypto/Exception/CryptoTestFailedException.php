<?php
namespace Defuse\Crypto\Exception;

class CryptoTestFailedException extends \Defuse\Crypto\Exception\CryptoException
{
    
}
