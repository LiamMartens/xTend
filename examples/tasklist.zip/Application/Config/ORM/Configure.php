<?php
    ORM::configure('sqlite:'.__DIR__.'/../../Data/tasklist.sqlite');
