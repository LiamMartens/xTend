<?php
	namespace Application;
	$app=\xTend\Core\getCurrentApp(__NAMESPACE__);
	$router=$app->getRouter();
	$router->home([
		'model' => 'Task',
		'controller' => 'IndexController@index',
		'view' => 'index'
	]);

	$router->post('task', [
		'model' => 'Task',
		'controller' => 'TaskController@post'
	]);

	$router->delete('task/rx{task}{[0-9]+}', [
		'model' => 'Task',
		'controller' => 'TaskController@delete'
	]);

	$router->error(0x0194, [
		'view' => '404'
	]);
