<?php namespace Application; $app=\xTend\Core\getCurrentApp(__NAMESPACE__); ?><!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Tasks</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    </head>
    <body>
        <div class="container">
            
    <div class="panel panel-default">
        <div class="panel-body">
            <?php if(count($app->getRequestDataHandler()->data()) > 0) { ?>
    <div class="alert alert-danger">
        <ul>
            <?php foreach($app->getRequestDataHandler()->data() as $error) { ?>
                <li><?php echo $error; ?></li>
            <?php } ?>
        </ul>
    </div>
<?php } ?>

            <form action="/task" method="POST" class="form-horizontal">
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="name">Task</label>
                    <div class="col-sm-6">
                        <input type="text" name="name" id="name" class="form-control" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-6">
                        <button class="btn btn-default" type="submit">ADD TASK</button>
                    </div>
                </div>
                <input type="hidden" name="token-task" value="<?php echo $app->getFormTokenHandler()->generate("task"); ?>" />
            </form>
        </div>
    </div>
    <?php if(count($app->getControllerHandler()->getController()->index())) { ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                Current tasks
            </div>
            <div class="panel-body">
                <table class="table table-striped">
                    <thead>
                        <th>Task</th>
                        <th>&nbsp;</th>
                    </thead>
                    <tbody>
                        <?php foreach($app->getControllerHandler()->getController()->index() as $task) { ?>
                            <tr>
                                <td><?php echo $task->name; ?></td>
                                <td>
                                    <form action="/task/<?php echo  $task->id ; ?>" method="POST">
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                        <input type="hidden" name="token-delete" value="<?php echo $app->getFormTokenHandler()->persistent("delete"); ?>" />
                                        <input type="hidden" name="_method" value="delete" />
                                    </form>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php } ?>

        </div>
    </body>
</html>
