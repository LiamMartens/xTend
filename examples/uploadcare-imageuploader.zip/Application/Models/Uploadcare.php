<?php
    namespace Application;
    class Uploadcare {
        private static $_entity = false;
        public static function get() {
            if(self::$_entity==false) {
                self::$_entity = new \Uploadcare\Api('19728128b74e08d28984', 'a07ac157698a263309c2');
            }
            return self::$_entity;
        }
    }
