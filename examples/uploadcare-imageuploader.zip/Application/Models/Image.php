<?php
    namespace Application;
    use \Model;
    use \ORM;
    class Image extends Model {
        public static $_table = 'images';
        public static function create() {
            return ORM::for_table('images')->create();
        }
        public static function all() {
            return Image::orderByAsc('created_at')->findMany();
        }
    }
