<?php
    namespace Application;
    class ImageController extends \xTend\Blueprints\BaseDataController {
        private $_image = false;
        public function get() {
            $hash = $this->_app->getUrlHandler()->hash;
            if($this->_image === false) {
                $this->_image = Image::where('hash', $hash)->findOne();
            }
            return $this->_image;
        }
    }
