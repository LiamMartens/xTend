<?php
    namespace Application;
    class UploadController extends \xTend\Blueprints\BaseDataController {
        public function upload() {
            $post = $this->_app->getRequestDataHandler()->post();
            if($post['file_id']=='') {
                return $this->_app->getUrlHandler()->navigate('');
            }
            $file = Uploadcare::get()->getFile($post['file_id']);
            $image = Image::create();
            $image->hash = bin2hex(random_bytes(20));
            $image->url = $file->getUrl();
            $image->save();
            return $this->_app->getUrlHandler()->navigate('');
        }
    }
