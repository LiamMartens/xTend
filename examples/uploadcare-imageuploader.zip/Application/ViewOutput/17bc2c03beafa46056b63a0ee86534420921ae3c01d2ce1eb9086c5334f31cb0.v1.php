<?php namespace Application; $app=\xTend\Core\getCurrentApp(__NAMESPACE__); ?><!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>AwesomeImage</title>

        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" href="/css/app.css" type="text/css">

        <script>
            UPLOADCARE_LIVE = false;
            UPLOADCARE_IMAGES_ONLY = true;
            UPLOADCARE_CROP = 'free';
        </script>
        <?php echo Uploadcare::get()->widget->getScriptTag(); ?>
    </head>
    <body>
        <div class="container">
            
    <div class="thumbnail">
        <img class="thumbnail__image" src="<?php echo  Uploadcare::get()->getFile($app->getControllerHandler()->getController()->get()->url)->getUrl() ; ?>" />
    </div>

        </div>
        
    </body>
</html>
