<?php namespace Application; $app=\xTend\Core\getCurrentApp(__NAMESPACE__); ?><!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>AwesomeImage</title>

        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" href="/css/app.css" type="text/css">

        <script>
            UPLOADCARE_LIVE = false;
            UPLOADCARE_IMAGES_ONLY = true;
            UPLOADCARE_CROP = 'free';
        </script>
        <?php echo Uploadcare::get()->widget->getScriptTag(); ?>
    </head>
    <body>
        <div class="container">
            
    <form action="/upload" method="POST" class="upload-form">
        <?php echo Uploadcare::get()->widget->getInputTag('file_id'); ?>
        <button class="upload-form__button button" type="submit">Upload</button>
    </form>
    <div class="thumbnails">
        <?php foreach($app->getViewHandler()->getView()->getData('images')() as $image) { ?>
            <div class="thumbnails__thumb">
                <a href="/image/<?php echo  $image->hash ; ?>">
                    <img class="thumbnails__thumb-image" src="<?php echo  Uploadcare::get()->getFile($image->url)->scaleCrop(300, 150)->op('quality/lightest')->op('progressive/yes')->getUrl(); ; ?>" />
                </a>
            </div>
        <?php } ?>
    </div>

        </div>
        
    <script>
        var widget = uploadcare.SingleWidget('[role=uploadcare-uploader]');
        widget.onUploadComplete(function() {
            document.querySelector('.upload-form__button').style.display = 'inline-block';
        });
    </script>

    </body>
</html>
