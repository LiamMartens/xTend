<layout value="app" />
<compile value="change" />
<version value="1" />

<section name="main">
    <div class="thumbnail">
        <img class="thumbnail__image" src="{{ Uploadcare::get()->getFile(@icontroller:get()->url)->getUrl() }}" />
    </div>
</section>
