<layout value="app" />
<compile value="change" />
<version value="1" />

<section name="main">
    <form action="/upload" method="POST" class="upload-form">
        <echo>Uploadcare::get()->widget->getInputTag('file_id')</echo>
        <button class="upload-form__button button" type="submit">Upload</button>
    </form>
    <div class="thumbnails">
        <foreach>
            <loop>@iapp:getViewHandler()->getView()->getData('images')() as $image</loop>
            <div class="thumbnails__thumb">
                <a href="/image/{{ $image->hash }}">
                    <img class="thumbnails__thumb-image" src="{{ Uploadcare::get()->getFile($image->url)->scaleCrop(300, 150)->op('quality/lightest')->op('progressive/yes')->getUrl(); }}" />
                </a>
            </div>
        </foreach>
    </div>
</section>

<section name="scripts">
    <script>
        var widget = uploadcare.SingleWidget('[role=uploadcare-uploader]');
        widget.onUploadComplete(function() {
            document.querySelector('.upload-form__button').style.display = 'inline-block';
        });
    </script>
</section>
