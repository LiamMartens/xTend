<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>AwesomeImage</title>

        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <css href="/css/app.css" />

        <script>
            UPLOADCARE_LIVE = false;
            UPLOADCARE_IMAGES_ONLY = true;
            UPLOADCARE_CROP = 'free';
        </script>
        <echo>Uploadcare::get()->widget->getScriptTag()</echo>
    </head>
    <body>
        <div class="container">
            <section name="main" />
        </div>
        <section name="scripts" />
    </body>
</html>
