<?php
    if(class_exists("ORM")) {
        ORM::configure('sqlite:'.__DIR__.'/../../Data/awesomeimage.sqlite');
    }
