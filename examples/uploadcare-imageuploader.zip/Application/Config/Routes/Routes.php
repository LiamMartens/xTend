<?php
	namespace Application;
	$app=\xTend\Core\getCurrentApp(__NAMESPACE__);

	$app->getRouter()->home([
		'models' => ['Image', 'Uploadcare'],
		'view' => 'index',
		'data' => ['images' => function() {
			return Image::all();
		}]
	]);

	$app->getRouter()->post('upload', [
		'models' => ['Image', 'Uploadcare'],
		'controller' => 'UploadController@upload'
	]);

	$app->getRouter()->get('image/{hash}', [
		'models' => ['Image', 'Uploadcare'],
		'controller' => 'ImageController',
		'view' => 'image'
	]);

	$app->getRouter()->error(0x0194, '404 - Page Not Found');
