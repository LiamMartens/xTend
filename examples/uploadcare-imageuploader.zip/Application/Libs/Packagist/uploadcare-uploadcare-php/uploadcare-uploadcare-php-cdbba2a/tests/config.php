<?php
define('PHPUNIT_UPLOADCARE_TESTSUITE', true);
define('UC_PUBLIC_KEY', 'demopublickey');
define('UC_SECRET_KEY', 'demoprivatekey');
date_default_timezone_set('UTC');
