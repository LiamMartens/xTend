Don't forget to set your Uploadcare API and Secret in `Application/Models/Uploadcare`
